package com.pingo.booster

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val pad by lazy { (18 * resources.displayMetrics.density).toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        montarTela()
    }

    private fun montarTela() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.TOP
        }
        root.addView(TextView(this).apply {
            text = "🐧 Game Booster Pingo"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = "Permita a sobreposição, ligue o painel e abra um jogo pela lista abaixo. A alça fica na borda esquerda da tela."
            textSize = 15f
            setPadding(0, 0, 0, pad)
        })
        addButton(root, "1. Permitir aparecer sobre outros apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addButton(root, "2. Permitir acesso ao Não Perturbe") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        addButton(root, "3. LIGAR painel flutuante") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Primeiro permita aparecer sobre outros apps.", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
                }
                val serviceIntent = Intent(this, OverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
                Toast.makeText(this, "Painel solicitado. Abra um jogo para testar.", Toast.LENGTH_LONG).show()
            }
        }
        addButton(root, "DESLIGAR painel") { stopService(Intent(this, OverlayService::class.java)) }
        root.addView(TextView(this).apply {
            text = "\nMEUS JOGOS INSTALADOS\nToque em um aplicativo para abrir."
            textSize = 18f
            setPadding(0, pad, 0, pad / 2)
        })

        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        if (apps.isEmpty()) {
            root.addView(TextView(this).apply { text = "Nenhum aplicativo encontrado." })
        } else {
            apps.forEach { info ->
                val label = info.loadLabel(packageManager).toString()
                addButton(root, "▶  $label") {
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                    else Toast.makeText(this, "Não foi possível abrir $label", Toast.LENGTH_SHORT).show()
                }
            }
        }
        setContentView(root)
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            setOnClickListener { action() }
        })
    }
}
