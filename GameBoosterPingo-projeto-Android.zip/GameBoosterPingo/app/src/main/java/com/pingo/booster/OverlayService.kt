package com.pingo.booster

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var handle: View? = null
    private var panel: LinearLayout? = null
    private var infoRam: TextView? = null
    private var botaoModo: Button? = null
    private var modoJogo = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        iniciarNotificacao()
        criarAlca()
    }

    private fun iniciarNotificacao() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("booster", "Game Booster", NotificationManager.IMPORTANCE_LOW))
        }
        val n = Notification.Builder(this, "booster")
            .setContentTitle("Game Booster Pingo ligado")
            .setContentText("Arraste a alça da esquerda para abrir o painel")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun criarAlca() {
        val v = View(this).apply {
            background = GradientDrawable().apply { setColor(Color.argb(180, 35, 115, 220)); cornerRadius = dp(8).toFloat() }
        }
        val lp = WindowManager.LayoutParams(
            dp(18), dp(180), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        var downX = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> downX = e.rawX
                MotionEvent.ACTION_UP -> if (e.rawX - downX > dp(25)) mostrarPainel()
            }
            true
        }
        wm.addView(v, lp)
        handle = v
    }

    private fun botao(txt: String, acao: () -> Unit): Button = Button(this).apply {
        text = txt
        setOnClickListener { acao() }
    }

    private fun mostrarPainel() {
        if (panel != null) return
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { setColor(Color.argb(245, 20, 30, 48)); cornerRadius = dp(16).toFloat() }
        }
        p.addView(TextView(this).apply { text = "🐧 GAME BOOSTER PINGO"; setTextColor(Color.WHITE); textSize = 17f })
        infoRam = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(0, dp(6), 0, dp(6)) }
        p.addView(infoRam)
        botaoModo = botao("Modo jogo: DESLIGADO") { alternarModoJogo() }
        p.addView(botaoModo)
        p.addView(botao("Atualizar RAM") { atualizarRam() })
        p.addView(botao("Abrir economia de bateria") { abrirTela(Settings.ACTION_BATTERY_SAVER_SETTINGS) })
        p.addView(botao("Fechar painel") { esconderPainel() })
        atualizarRam()
        val lp = WindowManager.LayoutParams(
            dp(270), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; x = dp(22) }
        p.setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_OUTSIDE) esconderPainel(); false }
        wm.addView(p, lp)
        panel = p
    }

    private fun esconderPainel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    private fun abrirTela(acao: String) {
        try { startActivity(Intent(acao).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { Toast.makeText(this, "Tela não disponível neste aparelho", Toast.LENGTH_SHORT).show() }
        esconderPainel()
    }

    private fun atualizarRam() {
        val am = getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        infoRam?.text = "RAM livre: ${mi.availMem / 1048576} MB de ${mi.totalMem / 1048576} MB"
    }

    private fun alternarModoJogo() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(this, "Permita o Não Perturbe na tela inicial do app (passo 2).", Toast.LENGTH_LONG).show()
            return
        }
        modoJogo = !modoJogo
        nm.setInterruptionFilter(if (modoJogo) NotificationManager.INTERRUPTION_FILTER_NONE else NotificationManager.INTERRUPTION_FILTER_ALL)
        botaoModo?.text = "Modo jogo: " + if (modoJogo) "LIGADO" else "DESLIGADO"
    }

    override fun onDestroy() {
        esconderPainel()
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        super.onDestroy()
    }
}
